import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { assessRegion, DEFAULT_RAINFALL_RISK_BANDS, foodRisk, householdDemandMLD, overallRisk, rainfallRisk, riskBand, transferQuantity, waterRisk, type Settings } from './calculations.ts';
import { regions } from './regions.ts';

const settings:Settings={householdLitres:135,planningDays:30};
const sample=regions[0];

describe('resource calculations',()=>{
  it('uses the specified risk-band boundaries',()=>{
    assert.equal(riskBand(6.99),'critical');
    assert.equal(riskBand(7),'high');
    assert.equal(riskBand(13.99),'high');
    assert.equal(riskBand(14),'moderate');
    assert.equal(riskBand(30),'moderate');
    assert.equal(riskBand(30.01),'low');
    assert.equal(riskBand(null),'unknown');
    assert.equal(waterRisk(6.99),'critical');
    assert.equal(foodRisk(30),'moderate');
  });
  it('uses exact configurable rainfall-deficit boundaries',()=>{
    assert.equal(rainfallRisk(-39.99),'low');
    assert.equal(rainfallRisk(-40),'moderate');
    assert.equal(rainfallRisk(-79.99),'moderate');
    assert.equal(rainfallRisk(-80),'high');
    assert.equal(rainfallRisk(-119.99),'high');
    assert.equal(rainfallRisk(-120),'critical');
    assert.equal(rainfallRisk(0),'low');
    assert.equal(rainfallRisk(null),'unknown');
    assert.equal(rainfallRisk(-50,{criticalDeficitMM:90,highDeficitMM:60,moderateDeficitMM:30}),'moderate');
    assert.equal(DEFAULT_RAINFALL_RISK_BANDS.criticalDeficitMM,120);
  });
  it('uses the highest known component for overall risk and requires water and food inputs',()=>{
    assert.equal(overallRisk('moderate','low','critical'),'critical');
    assert.equal(overallRisk('high','moderate','low'),'high');
    assert.equal(overallRisk('unknown','low','critical'),'unknown');
    assert.equal(overallRisk('low','unknown','low'),'unknown');
    const sampleAssessment=assessRegion(sample,settings);
    assert.equal(sampleAssessment.overallRisk,overallRisk(sampleAssessment.waterRisk,sampleAssessment.foodRisk,sampleAssessment.rainfallRisk));
    assert.equal(assessRegion({...sample,rainfallActualMM:-1},settings).overallRisk,sampleAssessment.overallRisk==='unknown'?'unknown':overallRisk(sampleAssessment.waterRisk,sampleAssessment.foodRisk,'unknown'));
    const rainfallRaisesOverall=assessRegion({...sample,usableWaterMCM:1000,foodStockMT:1_000_000,rainfallActualMM:0,rainfallNormalMM:120},settings);
    assert.equal(rainfallRaisesOverall.waterRisk,'low');
    assert.equal(rainfallRaisesOverall.foodRisk,'low');
    assert.equal(rainfallRaisesOverall.rainfallRisk,'critical');
    assert.equal(rainfallRaisesOverall.overallRisk,'critical');
    assert.match(rainfallRaisesOverall.overallReason,/rainfall critical/);
  });
  it('calculates rainfall departure and household demand using exact units',()=>{
    assert.equal(householdDemandMLD(1_000_000,135),135);
    assert.equal(assessRegion(sample,settings).rainfallDepartureMM,sample.rainfallActualMM-sample.rainfallNormalMM);
    assert.equal(householdDemandMLD(-1,135),null);
    assert.equal(householdDemandMLD(1_000_000,0),0);
  });
  it('calculates water runway from usable water, not raw storage',()=>{
    const result=assessRegion(sample,settings);
    const total=sample.population*settings.householdLitres/1_000_000+sample.agricultureWaterDemandMLD+sample.industryWaterDemandMLD;
    assert.equal(result.totalWaterMLD,total);
    assert.equal(result.waterDays,sample.usableWaterMCM*1000/total);
    assert.notEqual(result.waterDays,sample.waterStorageMCM*1000/total);
  });
  it('uses demand less stock for planning shortages and protects reserve in surplus',()=>{
    const result=assessRegion(sample,settings);
    const total=result.totalWaterMLD!;
    assert.equal(result.waterShortageMCM,Math.max(0,total*settings.planningDays/1000-sample.usableWaterMCM));
    assert.equal(result.waterSurplusMCM,Math.max(0,sample.usableWaterMCM-sample.waterReserveMCM-total*settings.planningDays/1000));
    assert.equal(result.foodShortageMT,Math.max(0,sample.foodDemandMTPerDay*settings.planningDays-sample.foodStockMT));
    assert.equal(result.foodSurplusMT,Math.max(0,sample.foodStockMT-sample.foodReserveMT-sample.foodDemandMTPerDay*settings.planningDays));
    assert.equal(assessRegion({...sample,foodReserveMT:sample.foodStockMT},settings).foodSurplusMT,0);
  });
  it('keeps missing, negative, and zero-demand cases explicit',()=>{
    const noWaterDemand=assessRegion({...sample,agricultureWaterDemandMLD:0,industryWaterDemandMLD:0,population:0},settings);
    assert.equal(noWaterDemand.waterDays,null);
    assert.equal(noWaterDemand.waterRisk,'unknown');
    const noFoodStock=assessRegion({...sample,foodStockMT:0},settings);
    assert.equal(noFoodStock.foodDays,0);
    assert.equal(noFoodStock.foodRisk,'critical');
    const invalid=assessRegion({...sample,usableWaterMCM:-1,foodDemandMTPerDay:-1,rainfallActualMM:-1},settings);
    assert.equal(invalid.waterDays,null);
    assert.equal(invalid.foodDays,null);
    assert.equal(invalid.rainfallDepartureMM,null);
    assert.equal(invalid.waterRisk,'unknown');
    assert.equal(invalid.foodRisk,'unknown');
    assert.equal(invalid.overallRisk,'unknown');
    assert.equal(assessRegion({...sample,rainfallNormalMM:-1},settings).rainfallRisk,'unknown');
    assert.equal(assessRegion({...sample,rainfallNormalMM:0},settings).rainfallDepartureMM,null);
    assert.equal(assessRegion({...sample,rainfallNormalMM:0},settings).rainfallRisk,'unknown');
    assert.equal(assessRegion({...sample,rainfallNormalMM:-1},settings).overallRisk,assessRegion(sample,settings).overallRisk==='unknown'?'unknown':overallRisk(assessRegion(sample,settings).waterRisk,assessRegion(sample,settings).foodRisk,'unknown'));
  });
  it('caps transfer quantity and blocks water routes without infrastructure',()=>{
    assert.equal(transferQuantity(20,12,8,'water',true),8);
    assert.equal(transferQuantity(5,12,8,'food',true),5);
    assert.equal(transferQuantity(20,12,8,'water',false),0);
    assert.equal(transferQuantity(20,-1,8,'food',true),0);
  });
});

describe('edge cases and transfer safety',()=>{
  it('rejects invalid risk inputs without inventing a risk score',()=>{
    assert.equal(riskBand(-0.1),'unknown');
    assert.equal(riskBand(Number.NaN),'unknown');
    assert.equal(rainfallRisk(-50,{criticalDeficitMM:40,highDeficitMM:50,moderateDeficitMM:10}),'unknown');
  });
  it('handles exact shortage and reserve-protected surplus boundaries',()=>{
    assert.equal(transferQuantity(0,10,5,'water',true),0);
    assert.equal(transferQuantity(10,0,5,'food',true),0);
    assert.equal(transferQuantity(10,10,0,'food',true),0);
    assert.equal(transferQuantity(Number.NaN,10,5,'water',true),0);
    assert.equal(transferQuantity(10,10,5,'water',false),0);
  });
  it('keeps zero household demand valid and non-negative',()=>{
    assert.equal(householdDemandMLD(0,135),0);
    assert.equal(householdDemandMLD(100,0),0);
    assert.equal(householdDemandMLD(Number.POSITIVE_INFINITY,135),null);
  });
  it('does not create negative shortage or surplus',()=>{
    const result=assessRegion({...sample,usableWaterMCM:10000,waterReserveMCM:100,foodStockMT:1000000,foodReserveMT:10},settings);
    assert.equal(result.waterShortageMCM,0);
    assert.equal(result.foodShortageMT,0);
    assert.ok((result.waterSurplusMCM??-1)>=0);
    assert.ok((result.foodSurplusMT??-1)>=0);
  });
});
